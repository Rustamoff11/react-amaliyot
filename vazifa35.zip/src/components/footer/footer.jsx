import './footer.css'

function Footer() {
  return (
    <div className='footer'>
<div className='footer-container container'>
<p>All rigt reserve <a href="https://www.youtube.com/@qiziqarli_UZ">Nodirbek Rustamov</a></p>
</div>
    </div>
  )
}

export default Footer